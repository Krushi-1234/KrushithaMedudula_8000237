import java.sql.*;

public class JDBCConnection {
    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/event_db";
        String user = "root";
        String password = "Krushi,1234";

        try {
            Connection con =
                DriverManager.getConnection(url, user, password);

            Statement stmt = con.createStatement();

            ResultSet rs =
                stmt.executeQuery("SELECT * FROM Users");

            while(rs.next()) {
                System.out.println(
                    rs.getInt("user_id") + " "
                    + rs.getString("full_name")
                );
            }

            con.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}