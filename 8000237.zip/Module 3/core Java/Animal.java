class Animal { void sound(){System.out.println("Animal");} }
class Dog extends Animal { void sound(){System.out.println("Bark");} }