public class DataTypes {
    public static void main(String[] args) {
        int a = 10;
        float b = 2.5f;
        double c = 5.55;
        char d = 'A';
        boolean e = true;

        System.out.println(a+" "+b+" "+c+" "+d+" "+e);
    }
}