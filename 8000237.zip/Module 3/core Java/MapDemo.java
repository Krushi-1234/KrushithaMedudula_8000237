import java.util.*;
public class MapDemo {
    public static void main(String[] args) {
        HashMap<Integer,String> m = new HashMap<>();
        m.put(1,"A");
        System.out.println(m.get(1));
    }
}