import java.sql.*;

public class StudentDAO {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/event_db";
        String user = "root";
        String password = "Krushi,1234";

        try {

            Connection con =
                DriverManager.getConnection(url,user,password);

            String insert =
                "INSERT INTO Users(full_name,email,city,registration_date) VALUES(?,?,?,?)";

            PreparedStatement ps =
                con.prepareStatement(insert);

            ps.setString(1,"John");
            ps.setString(2,"john@gmail.com");
            ps.setString(3,"Hyderabad");
            ps.setDate(4,Date.valueOf("2025-06-01"));

            ps.executeUpdate();

            String update =
                "UPDATE Users SET city=? WHERE user_id=?";

            PreparedStatement ps2 =
                con.prepareStatement(update);

            ps2.setString(1,"Mumbai");
            ps2.setInt(2,1);

            ps2.executeUpdate();

            System.out.println("Insert and Update Successful");

            con.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}