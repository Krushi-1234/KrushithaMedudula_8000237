interface Playable { void play(); }
class Guitar implements Playable {
    public void play(){System.out.println("Guitar");}
}