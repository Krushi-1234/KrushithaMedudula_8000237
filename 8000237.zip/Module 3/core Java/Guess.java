import java.util.*;

public class Guess {
    public static void main(String[] args) {
        Random r = new Random();
        int num = r.nextInt(100)+1;

        Scanner sc = new Scanner(System.in);
        int guess;

        do {
            guess = sc.nextInt();

            if(guess > num) System.out.println("High");
            else if(guess < num) System.out.println("Low");

        } while(guess != num);

        System.out.println("Correct!");
    }
}