import java.io.*;
public class ReadFile {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("out.txt"));
        System.out.println(br.readLine());
    }
}