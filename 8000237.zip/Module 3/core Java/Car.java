class Car {
    String make="Toyota";
    void show(){System.out.println(make);}
}
