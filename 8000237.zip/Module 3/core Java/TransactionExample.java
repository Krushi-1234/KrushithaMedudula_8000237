import java.sql.*;

public class TransactionExample {

    public static void main(String[] args) {

        String url = "jdbc:mysql://localhost:3306/event_db";
        String user = "root";
        String password = "Krushi,1234";

        try {

            Connection con =
                DriverManager.getConnection(url,user,password);

            con.setAutoCommit(false);

            Statement stmt = con.createStatement();

            stmt.executeUpdate(
                "UPDATE accounts SET balance = balance - 1000 WHERE id=1");

            stmt.executeUpdate(
                "UPDATE accounts SET balance = balance + 1000 WHERE id=2");

            con.commit();

            System.out.println("Transaction Successful");

            con.close();

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
