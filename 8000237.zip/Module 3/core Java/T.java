class T extends Thread {
    public void run(){System.out.println("Thread");}
}