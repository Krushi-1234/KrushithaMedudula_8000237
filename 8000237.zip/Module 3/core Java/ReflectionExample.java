import java.lang.reflect.Method;

public class ReflectionExample {

    public void greet() {
        System.out.println("Hello Reflection");
    }

    public static void main(String[] args) {

        try {

            Class<?> cls =
                    Class.forName("ReflectionExample");

            Method[] methods =
                    cls.getDeclaredMethods();

            for(Method m : methods) {
                System.out.println(m.getName());
            }

            Object obj =
                    cls.getDeclaredConstructor().newInstance();

            Method method =
                    cls.getMethod("greet");

            method.invoke(obj);

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
