public class VirtualThreadsExample {

    public static void main(String[] args) {

        for(int i=1;i<=100;i++) {

            int num = i;

            Thread.startVirtualThread(() -> {
                System.out.println(
                        "Virtual Thread : " + num);
            });
        }

        try {
            Thread.sleep(2000);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}