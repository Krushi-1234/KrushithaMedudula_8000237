import java.util.*;
public class Lambda {
    public static void main(String[] args) {
        List<String> l = Arrays.asList("b","a");
        Collections.sort(l,(a,b)->a.compareTo(b));
    }
}
