import java.io.*;
public class WriteFile {
    public static void main(String[] args) throws Exception {
        FileWriter f = new FileWriter("out.txt");
        f.write("Hello");
        f.close();
    }
}