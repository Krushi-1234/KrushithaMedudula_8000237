import java.util.*;
public class ListDemo {
    public static void main(String[] args) {
        ArrayList<String> a = new ArrayList<>();
        a.add("John");
        System.out.println(a);
    }
}