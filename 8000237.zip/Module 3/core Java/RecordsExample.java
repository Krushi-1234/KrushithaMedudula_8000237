import java.util.List;

record Person(String name, int age) {}

public class RecordsExample {
    public static void main(String[] args) {

        Person p1 = new Person("Alice", 22);
        Person p2 = new Person("Bob", 18);

        System.out.println(p1);
        System.out.println(p2);

        List<Person> persons = List.of(p1, p2);

        persons.stream()
               .filter(p -> p.age() >= 20)
               .forEach(System.out::println);
    }
}