public class Casting {
    public static void main(String[] args) {
        double d = 10.5;
        int i = (int)d;

        int x = 5;
        double y = x;

        System.out.println(i + " " + y);
    }
}