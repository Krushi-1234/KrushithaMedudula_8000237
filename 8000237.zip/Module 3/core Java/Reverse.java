public class Reverse {
    public static void main(String[] args) {
        String s="hello";
        System.out.println(new StringBuilder(s).reverse());
    }
}