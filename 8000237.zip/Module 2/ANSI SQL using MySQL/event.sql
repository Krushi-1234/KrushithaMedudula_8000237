
-- =========================
-- 1. CREATE & USE DATABASE
-- =========================
CREATE DATABASE IF NOT EXISTS event_db;
USE event_db;

-- =========================
-- 2. DROP TABLES (CLEAN START)
-- =========================
DROP TABLE IF EXISTS Resources;
DROP TABLE IF EXISTS Feedback;
DROP TABLE IF EXISTS Registrations;
DROP TABLE IF EXISTS Sessions;
DROP TABLE IF EXISTS Events;
DROP TABLE IF EXISTS Users;

-- =========================
-- 3. CREATE TABLES
-- =========================

CREATE TABLE Users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    city VARCHAR(100),
    registration_date DATE
);

CREATE TABLE Events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200),
    description TEXT,
    city VARCHAR(100),
    start_date DATETIME,
    end_date DATETIME,
    status VARCHAR(20),
    organizer_id INT
);

CREATE TABLE Sessions (
    session_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    title VARCHAR(200),
    speaker_name VARCHAR(100),
    start_time DATETIME,
    end_time DATETIME
);

CREATE TABLE Registrations (
    registration_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_id INT,
    registration_date DATE
);

CREATE TABLE Feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    event_id INT,
    rating INT,
    comments TEXT,
    feedback_date DATE
);

CREATE TABLE Resources (
    resource_id INT PRIMARY KEY AUTO_INCREMENT,
    event_id INT,
    resource_type VARCHAR(20),
    resource_url VARCHAR(255),
    uploaded_at DATETIME
);

-- =========================
-- 4. INSERT SAMPLE DATA
-- =========================

INSERT INTO Users VALUES
(1,'Alice Johnson','alice@example.com','New York','2024-12-01'),
(2,'Bob Smith','bob@example.com','Los Angeles','2024-12-05'),
(3,'Charlie Lee','charlie@example.com','Chicago','2024-12-10'),
(4,'Diana King','diana@example.com','New York','2025-01-15'),
(5,'Ethan Hunt','ethan@example.com','Los Angeles','2025-02-01');

INSERT INTO Events VALUES
(1,'Tech Meetup','Tech event','New York','2025-06-10 10:00:00','2025-06-10 16:00:00','upcoming',1),
(2,'AI Conference','AI event','Chicago','2025-05-15 09:00:00','2025-05-15 17:00:00','completed',3),
(3,'Frontend Bootcamp','Web dev','Los Angeles','2025-07-01 10:00:00','2025-07-03 16:00:00','upcoming',2);

INSERT INTO Sessions VALUES
(1,1,'Opening Keynote','Dr Tech','2025-06-10 10:00:00','2025-06-10 11:00:00'),
(2,1,'Web Future','Alice Johnson','2025-06-10 11:15:00','2025-06-10 12:30:00'),
(3,2,'AI in Healthcare','Charlie Lee','2025-05-15 09:30:00','2025-05-15 11:00:00'),
(4,3,'HTML Basics','Bob Smith','2025-07-01 10:00:00','2025-07-01 12:00:00');

INSERT INTO Registrations VALUES
(1,1,1,'2025-05-01'),
(2,2,1,'2025-05-02'),
(3,3,2,'2025-04-30'),
(4,4,2,'2025-04-28'),
(5,5,3,'2025-06-15');

INSERT INTO Feedback VALUES
(1,3,2,4,'Great insights!','2025-05-16'),
(2,4,2,5,'Very informative','2025-05-16'),
(3,2,1,3,'Okay event','2025-06-11');

INSERT INTO Resources VALUES
(1,1,'pdf','https://portal.com/agenda.pdf','2025-05-01 10:00:00'),
(2,2,'image','https://portal.com/ai.jpg','2025-04-20 09:00:00'),
(3,3,'link','https://portal.com/html5','2025-06-25 15:00:00');

-- =========================
-- 5. SAMPLE QUERIES (RUN ANY TIME)
-- =========================

-- 1 Upcoming Events
SELECT * FROM Events WHERE status='upcoming';

-- 2 Top Rated Events
SELECT event_id, AVG(rating) avg_rating
FROM Feedback
GROUP BY event_id;

-- 3 Inactive Users (simple version)
SELECT * FROM Users
WHERE user_id NOT IN (SELECT user_id FROM Registrations);

-- 4 Sessions per Event
SELECT event_id, COUNT(*) session_count
FROM Sessions
GROUP BY event_id;

-- 5 Most Active Cities
SELECT city, COUNT(*) total_users
FROM Users
GROUP BY city;