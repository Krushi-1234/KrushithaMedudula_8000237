console.log("Welcome to the Community Portal");

window.onload = function() {
    alert("Page fully loaded");

    // Retrieve stored event type
    const savedEvent = localStorage.getItem("preferredEvent");

    if(savedEvent) {
        document.getElementById("eventType").value = savedEvent;
    }
};

// Before unload warning
window.onbeforeunload = function() {
    return "You have unsaved changes. Are you sure you want to leave?";
};

// Variables and Data Types
const eventName = "Music Festival";
const eventDate = "20 June 2026";
let availableSeats = 50;

console.log(`${eventName} on ${eventDate}`);

// Event Array
const events = [
    {
        name: "Music Festival",
        category: "music",
        seats: 50,
        date: "2026-06-20"
    },
    {
        name: "Food Carnival",
        category: "food",
        seats: 0,
        date: "2026-06-22"
    }
];

// Display valid events
function displayEvents() {

    events.forEach(event => {

        if(event.seats > 0) {
            console.log(event.name);
        }
        else {
            console.log(`${event.name} is full`);
        }
    });
}

// Functions
function addEvent(event) {
    events.push(event);
}

function registerUser() {

    try {

        if(availableSeats <= 0) {
            throw new Error("No seats available");
        }

        availableSeats--;
        alert("Registration successful");
    }
    catch(error) {
        console.log(error.message);
    }
}

function filterEventsByCategory(category, callback) {

    const filtered = events.filter(event => event.category === category);

    callback(filtered);
}

// Closure Example
function registrationCounter() {

    let count = 0;

    return function() {
        count++;
        return count;
    };
}

const musicRegistrations = registrationCounter();
console.log(musicRegistrations());

// Class and Prototype
class EventPortal {

    constructor(name, seats) {
        this.name = name;
        this.seats = seats;
    }
}

EventPortal.prototype.checkAvailability = function() {
    return this.seats > 0;
};

const sampleEvent = new EventPortal("Workshop", 20);
console.log(sampleEvent.checkAvailability());

console.log(Object.entries(sampleEvent));

// Array Methods
const musicEvents = events.filter(event => event.category === "music");
console.log(musicEvents);

const formattedEvents = events.map(event => `Workshop on ${event.name}`);
console.log(formattedEvents);

// DOM Manipulation
const mainSection = document.querySelector("main");

const card = document.createElement("div");
card.innerHTML = "Dynamic Event Card";
mainSection.appendChild(card);

// Register Button
function registerEvent(eventName) {
    alert(`Registered for ${eventName}`);
}

// Filter Category
function filterCategory() {

    const category = document.getElementById("categoryFilter").value;

    console.log(`Selected Category: ${category}`);
}

// Validate Phone
function validatePhone() {

    const phone = document.getElementById("phone").value;

    if(phone.length !== 10) {
        alert("Enter valid 10 digit phone number");
    }
}

// Show Event Fee
function showFee() {

    const eventType = document.getElementById("eventType").value;
    const feeDisplay = document.getElementById("feeDisplay");

    let fee = "";

    if(eventType === "Music") {
        fee = "Fee: ₹500";
    }
    else if(eventType === "Food") {
        fee = "Fee: ₹300";
    }
    else if(eventType === "Workshop") {
        fee = "Fee: ₹700";
    }

    feeDisplay.innerHTML = fee;

    // Save preference
    localStorage.setItem("preferredEvent", eventType);
}

// Confirmation
function showConfirmation() {
    document.getElementById("outputMessage").value =
    "Registration submitted successfully";
}

// Double Click Image
function enlargeImage(img) {

    img.style.width = "300px";
    img.style.height = "250px";
}

// Character Count
function countCharacters() {

    const text = document.getElementById("feedback").value;

    document.getElementById("charCount").innerHTML =
    `Characters: ${text.length}`;
}

// Video Ready
function videoReady() {

    document.getElementById("videoMessage").innerHTML =
    "Video ready to play";
}

// Clear Preferences
function clearPreferences() {

    localStorage.clear();
    sessionStorage.clear();

    alert("Preferences cleared");
}

// Geolocation
function findLocation() {

    if(navigator.geolocation) {

        navigator.geolocation.getCurrentPosition(

            function(position) {

                document.getElementById("locationResult").innerHTML =
                `Latitude: ${position.coords.latitude}<br>
                Longitude: ${position.coords.longitude}`;
            },

            function(error) {

                if(error.code === error.PERMISSION_DENIED) {
                    alert("Location permission denied");
                }
                else {
                    alert("Unable to retrieve location");
                }
            },

            {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            }
        );
    }
}

// Form Handling
const form = document.getElementById("registrationForm");

form.addEventListener("submit", function(event) {

    event.preventDefault();

    const name = form.elements["name"].value;
    const email = form.elements["email"].value;

    if(name === "" || email === "") {
        alert("Please fill all fields");
        return;
    }

    console.log(name, email);

    // AJAX / Fetch API
    fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name,
            email
        })
    })
    .then(response => response.json())
    .then(data => {

        setTimeout(() => {
            alert("Registration sent successfully");
        }, 2000);

        console.log(data);
    })
    .catch(error => {
        console.log(error);
    });
});

// Async Await Example
async function fetchEvents() {

    try {

        console.log("Loading...");

        const response = await fetch(
            "https://jsonplaceholder.typicode.com/posts"
        );

        const data = await response.json();

        console.log(data);
    }
    catch(error) {
        console.log(error);
    }
}

fetchEvents();

// Destructuring and Spread Operator
const clonedEvents = [...events];

const { name, category } = events[0];
console.log(name, category);

// jQuery
$(document).ready(function() {

    $('#registerBtn').click(function() {
        $('.eventCard').fadeOut().fadeIn();
    });
});